package com.capgemini.rest.client;


public interface IRequest {

	void execute() throws Exception;
}
