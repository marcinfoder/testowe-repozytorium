package com.capgemini.validation;

import org.springframework.beans.factory.FactoryBean;

public class ValidationResolver implements FactoryBean<Object> {

	@Override
	public Object getObject() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<?> getObjectType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isSingleton() {
		// TODO Auto-generated method stub
		return false;
	}

}
